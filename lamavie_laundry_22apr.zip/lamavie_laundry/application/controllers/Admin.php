<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller

{
 function __construct()
  {
                parent::__construct();
                $this->load->helper('url');
                $this->load->model('admin/authentication_model');                
                $this->load->model('admin/admin_common_model');
                
                $this->load->library(array('form_validation','session'));
                $this->load->helper('string');
                 error_reporting(0);
                  define("SITE_EMAIL",'info@cskwt.com'); 
                
  }

  public

  function index()
  {
    $this->load->view('admin/login');
  }
  

  public

  function dashboard()
  {
    $this->load->view('admin/dashboard');
    
  }


  public

  function page($page)
  {
     $this->load->view('admin/'.$page);
  }
  

  public

  function go()
  {
    
      $result = $this->authentication_model->admin_login();
      if(!$result) {
        $msg = array(
           'msg' =>'<strong>Error!</strong> Invalid Username and Password. Log in failed.','res' => 0
              );
                             $this->session->set_userdata($msg);
                             redirect('admin');
      }
      else {
        redirect('admin/dashboard', $message);
      }
    
  }  

  public function logout(){
    $this->session->sess_destroy();
   redirect('admin');
   }  


public

  function display_rides()
  { 
   $action = $this->input->get_post('act');
   
    $branch = $this->session->userdata('admin');
         $branch_id =   $branch->id;
         
  
   
     if($action=='All'){
    $data['title'] = "All Order";
    // $this->db->order_by("id", "desc");
   // $data['rideList'] =$this->db->query("SELECT * FROM place_order WHERE branch_id = $branch_id ORDER BY id DESC")->result_array();
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id]);
   }
   
   if($action=='Pending'){
    $data['title'] = "Pending";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Pending']);
   }
   if($action=='Confirmed'){
    $data['title'] = "Confirmed";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Confirmed']);
   }
   if($action=='Pickup'){
    $data['title'] = "Pickup";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Pickup']);
   }    
   if($action=='Progress'){
    $data['title'] = "Progress";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Progress']);
   }
    if($action=='Shipped'){
    $data['title'] = "Shipped";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Shipped']);
   }
    if($action=='Delivered'){
    $data['title'] = "Delivered";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Delivered']);
   }
      if($action=='Cancel'){
    $data['title'] = "Cancelled";
    $data['rideList'] = $this->admin_common_model->get_where('place_order',['branch_id'=>$branch_id,'status'=>'Cancelled']);
   }
  
     $this->load->view('admin/all_order_list',$data);
  }









function chat_insert()
				{
					$sender_id = $_POST['sender_id'];
					$receiver_id = $_POST['receiver_id'];
					$chat_message = $_POST['chat_message'];
					date_default_timezone_set('Asia/Kolkata');
					$arr_data = [
				   'sender_id'=>$sender_id,
				   'receiver_id'=>$receiver_id,
				   'chat_message'=>$chat_message,
				   'date'=>date('Y-m-d h:i:s')
				   ];

			    $result = $this->admin_common_model->insert_data('kaise_chat_detail',$arr_data);  
                $this->load->view('admin/chat_ajax');
				}



function get_new(){ 
    
    
    
      $sender_id = $_POST['sender_id'];
      $receiver_id = $_POST['receiver_id'];  


$Dataaa=file_get_contents("https://lamavietech.ml/lamavie_laundry/admin/get_chat?receiver_id=$sender_id&sender_id=$receiver_id");
$data['rt']=json_decode($Dataaa,true);
//print_r($Dataaa); die;
$this->load->view('admin/chat_ajax',$data);
}


function get_new11(){ 
    
        	$admin = $this->session->userdata('admin'); 
          $admin_id = $admin->id;
    
    
      $sender_id = $admin_id;
       $receiver_id = $_POST['receiver_id']; 


$Dataaa=file_get_contents("https://lamavietech.ml/lamavie_laundry/admin/get_chat?receiver_id=$sender_id&sender_id=$receiver_id");
$data['rt']=json_decode($Dataaa,true);
//print_r($Dataaa); die;
$this->load->view('admin/chat_ajax',$data);
}






public

function get_chat()
	{
	$sender_id = $this->input->get_post('sender_id', TRUE);
	$receiver_id = $this->input->get_post('receiver_id', TRUE);
	$this->db->where('sender_id', $sender_id);
	$this->db->where('receiver_id', $receiver_id);
	$this->db->or_where('sender_id', $receiver_id);
	$this->db->where('receiver_id', $sender_id);
	$this->db->order_by('id', 'ASC');
	$info = $this->db->get('kaise_chat_detail');
	$chat = $info->result_array();
	if ($chat)
		{
		$i = 0;
		foreach($chat as $val)
			{
			$sender = $this->admin_common_model->get_where('admin', ['admin_no' => $val['sender_id']]);
		
			$val['chat_image'] = SITE_URL . 'uploads/images/' . $val['chat_image'];
	
			$exp1 = $exp2 = "";
			$clr_id = $val['clear_chat'];
			$exp = explode(',', $clr_id);
			if (isset($exp[0]))
				{
				$exp1 = $exp[0];
				}

			if (isset($exp[1]))
				{
				$exp2 = $exp[1];
				}

			if ($exp1 != $receiver_id && $exp2 != $receiver_id)
				{
				$i++;
				$json[] = $val;
				} //end if
			}

		if ($i == 0)
			{
			$data = array(
				"result" => [],
					"message" => "unsuccessful",
						"status" => "0"
			);
			}
			else
			{
			    	$data = array(
				"result" => $json,
					"message" => "successful",
						"status" => "1"
			);
			}

		$arr_where = ['sender_id' => $sender_id, 'receiver_id' => $receiver_id]; //print_r($arr_where);
		$this->admin_common_model->update_data('kaise_chat_detail', ['status' => 'SEEN'], $arr_where);
		}
	  else
		{
			$data = array(
				"result" =>[],
					"message" => "unsuccessful",
						"status" =>0
			);
		}

	header('Content-type: application/json');
	echo json_encode($data);
	}



















 function update_profile()
  {
     
      $id = $this->input->post('id');
$this->load->library('form_validation');

$this->form_validation->set_error_delimiters('<div class="error">', '</div>');


$this->form_validation->set_rules('name', 'Username', 'required');
$this->form_validation->set_rules('email', 'Email', 'required|valid_email');
$this->form_validation->set_rules('mobile', 'Mobile No.', 'required|regex_match[/^[0-9]{10}$/]');
$this->form_validation->set_rules('password', 'Password', 'required');
$this->form_validation->set_rules('confirm_password', 'Confirm Password', 'required|matches[password]');


if ($this->form_validation->run() == FALSE) {
$this->load->view('admin/profile');
} else {

$arr_data = array(
'name' => $this->input->post('name'),
'email' => $this->input->post('email'),
'mobile' => $this->input->post('mobile'),
);

 if ($_FILES['image']['name']!='') {
        $n = rand(0, 100000);
        $img = "update_profile_" . $n . '.png';
        move_uploaded_file($_FILES['image']['tmp_name'], "uploads/images/" . $img);
        $arr_data['image'] = $img;
      }




$this->admin_common_model->update_data("admin",$arr_data,['id'=>$id]);
$data['message'] = 'Data Inserted Successfully';

$this->load->view('admin/profile');

}  
     
     
     
  }


    
    function update_password()
  {
      $password = $_POST['password'];
      $id = $_POST['id'];
      $this->admin_common_model->update_data("users",['password'=>$password],['id'=>$id]);
  }



  public function admin_logout(){
        $this->session->unset_userdata('admin');
        return redirect('admin');   
  }


function change_code()
  {
      
    $id = $this->input->post('id'); 
   
    $fetch = $this->admin_common_model->get_where('category', ['id'=>$id]);
    
    if ($fetch) {  
        
        $json = ['result' => 'successfull', 'status' => '1', 'message' => 'successfull'];

    } else {
        $json = ['result' => 'unsuccessfull', 'status' => '0', 'message' => 'Invalid record'];
    }

    header('Content-type:application/json'); 
    echo json_encode($json);

  }

 public function get_subcate()
      { 
         $selected = $this->input->get_post('selected');
         $id1 =  $this->input->get_post('id');
         
        if($id1=='') {
            $selected2 =$selected;
           
        }else{
             $selected2 =$id1;
        }
        
      
        $arr_where = ['id'=>$selected2];
        $cnt = $this->admin_common_model->get_where('category', $arr_where);
        $service_id = $cnt[0]['id'];
        $fetch = $this->admin_common_model->get_where('sub_category',['category_id'=>$service_id]);
     
        if($fetch){

          foreach ($fetch as $val) { ?>
             
            <option value="<?=$val['id']?>" <?php if($val['id'] == $selected){echo 'selected';}?> ><?=$val['sub_cat_name']?></option>
            
             
          <?php }
 
        }
        
      }





  public function delete_data(){
        $table = $this->input->post('table');
        $id = $this->input->post('id');
        $this->admin_common_model->delete_data($table,['id'=>$id]);
  }
  
   public function delete_data1(){
        $table = $this->input->post('table');
        $id = $this->input->post('product_id');
        $this->admin_common_model->delete_data($table,['product_id'=>$id]);
  }

  public function delete_data2(){
        $table = $this->input->post('table');
        $id = $this->input->post('fav_user_id');
        $this->admin_common_model->delete_data($table,['fav_user_id'=>$id]);
  }
  
   public function delete_image(){
        $table = $this->input->post('table');
        $id = $this->input->post('product_id');
        $this->admin_common_model->delete_data($table,['product_id'=>$id]);
  }
 
  
   public function create_owner(){
       
       $user_id = $this->input->post('user_id');
       $shop_id = $this->input->post('shop_id');
       if($shop_id!=''){
         $this->admin_common_model->update_data('shop',['user_id'=>$user_id],['id'=>$shop_id]);
       }
       return redirect('admin/view_page/userList');   
  }

  function updateStatus()
  {
      
       $driver_id = $_POST['driver_id'];
       $order_id = $_POST['order_id'];
       
      $this->admin_common_model->update_data("place_order",['driver_id'=>$driver_id],['id'=>$order_id]);
     
      }
      
     function UpdatePaymentStatus()
  {
      
       $payment_status = $_POST['payment_status'];
       $order_id = $_POST['order_id'];
       
      $this->admin_common_model->update_data("place_order",['payment_status'=>$payment_status],['id'=>$order_id]);
     
      }   
      
      
     function updateStatusAssgine()
  {
      
      $otp = rand(0000,9999);
      
      $driver_id = $_POST['driver_id'];
      $id = $_POST['id'];
      $this->admin_common_model->update_data("place_order",['status'=>'Confirmed','driver_id'=>$driver_id,'otp'=>$otp],['id'=>$id]);
      
      
      $driver =   $this->admin_common_model->get_where("users",['id'=>$driver_id]);
      
      
         $user_message_apk1 = array(
      "message" => array(
        "result" => "successful",
        "key" => 'Confirmed',
        "alert" => 'new order assigne',
        'driver_id' => $driver_id ,
         
     
      )
    );
    $register_userid = array(
      $driver[0]['register_id']
    );
    
  $this->Webservice_model->user_apk_notification($register_userid, $user_message_apk1);
      
      
      
      
      }
        
      
      
      
      
      
      
  
    function update_driver()
  {
      $driver_id = $_POST['driver_id'];
      $id = $_POST['id'];
      $this->admin_common_model->update_data("place_order",['driver_id'=>$driver_id],['id'=>$id]);
     // echo $this->db->last_query();
  }

  
  
  
  function update_status()
  {
      $status = $_POST['status'];
      $id = $_POST['id'];
      $this->admin_common_model->update_data("users",['status'=>$status],['id'=>$id]);
     // echo $this->db->last_query();
  }





 function demo()
  {
     $aa =  $this->admin_common_model->get_where("users",['status'=>'Deactive']);
      if($aa){
         $this->admin_common_model->update_data("users",['status'=>'Active'],['status'=>'Deactive']);  
         echo "true";
      }else{
          echo 'false';
      }
  }

function demo1()
  {
    // $active = 'Active'; 
      
 
    // $request = $this->db->query("UPDATE users SET status = '$active'")->result_array();
     
 $this->admin_common_model->update_data("users",['status'=>'Active'],['status'=>'Deactive']);
       return redirect('admin/view_page/userList'); 
  }



// end class
}
