<!DOCTYPE html>
<html>
<head>
	<title>Article</title>
</head>
<style type="text/css">
	body
	{
		background: #0d0e0d;
	    color: #fff;
	    font-size: 14px;
	    padding: 20px;
	    font-family: sans-serif;
	}
	h1
	{
		color: #ffd770
	}
	p
	{
		line-height: 20px;
	}
	img	{width: 100%;}
	.right-img
	{
		float: right;
    width: 45%;
	}
	.left-deatils
	{
		float: left;
	    width: 48%;
	    font-size: 13px;
	    margin-top: 0px;
	}
</style>
<body>

	<h1>What is Lorem Ipsum?</h1>
	<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>
	<div class="">
		<img src="<?php echo base_url('assets/post.jpg'); ?>" class="right-img">
		<p class="left-deatils">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book leap into electronic typesetting, remaining essentially unchanged. .</p>
		
	</div>
	<div style="display: block;
    width: 100%;
    clear: both;">
	<p>
		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
		Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
	</p>
	</div>
	<div>
		<img src="<?php echo base_url('assets/post.jpg'); ?>" >
	</div>

</body>
</html>